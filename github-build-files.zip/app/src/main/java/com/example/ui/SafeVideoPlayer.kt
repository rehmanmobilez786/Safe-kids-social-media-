package com.example.ui

import android.annotation.SuppressLint
import android.graphics.Bitmap
import android.net.Uri
import android.view.View
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.example.data.VideoItem

@OptIn(ExperimentalMaterial3Api::class)
@SuppressLint("SetJavaScriptEnabled")
@Composable
fun SafeVideoPlayer(
    video: VideoItem,
    isUrdu: Boolean,
    onBack: () -> Unit
) {
    var isLoading by remember { mutableStateOf(true) }
    var webViewInstance by remember { mutableStateOf<WebView?>(null) }
    var customView by remember { mutableStateOf<View?>(null) }
    var customViewCallback by remember { mutableStateOf<WebChromeClient.CustomViewCallback?>(null) }

    // Intercept back button if fullscreen custom view is active
    BackHandler(enabled = customView != null) {
        customViewCallback?.onCustomViewHidden()
        customView = null
        customViewCallback = null
    }

    if (customView != null) {
        // Fullscreen mode
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black)
        ) {
            AndroidView(
                factory = { customView!! },
                modifier = Modifier.fillMaxSize()
            )
        }
        return
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { 
                    Text(
                        text = video.title,
                        style = MaterialTheme.typography.titleMedium,
                        maxLines = 1
                    ) 
                },
                navigationIcon = {
                    IconButton(
                        onClick = onBack,
                        modifier = Modifier.testTag("video_player_back_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = if (isUrdu) "پیچھے جائیں" else "Go Back"
                        )
                    }
                },
                actions = {
                    IconButton(
                        onClick = {
                            isLoading = true
                            val (html, baseUrl) = generatePlayerPayload(video)
                            webViewInstance?.loadDataWithBaseURL(baseUrl, html, "text/html", "UTF-8", null)
                        },
                        modifier = Modifier.testTag("video_player_reload_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Refresh,
                            contentDescription = if (isUrdu) "تازہ کریں" else "Reload"
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer,
                    titleContentColor = MaterialTheme.colorScheme.onPrimaryContainer
                )
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Safety Filter notice
            Card(
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.secondaryContainer
                ),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 8.dp)
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (isUrdu) "🔒 سیکیورٹی فلٹر آن ہے: بیرونی لنکس اور اشتہارات بند ہیں" 
                               else "🔒 Security Filter Active: External links & ads blocked",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSecondaryContainer,
                        modifier = Modifier.weight(1f)
                    )
                    Badge(
                        containerColor = MaterialTheme.colorScheme.primary
                    ) {
                        Text(
                            text = video.platform,
                            style = MaterialTheme.typography.labelSmall,
                            color = Color.White,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }
            }

            // Secure web container
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .padding(12.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .background(Color.Black),
                contentAlignment = Alignment.Center
            ) {
                AndroidView(
                    factory = { context ->
                        WebView(context).apply {
                            layoutParams = ViewGroup.LayoutParams(
                                ViewGroup.LayoutParams.MATCH_PARENT,
                                ViewGroup.LayoutParams.MATCH_PARENT
                            )
                            setLayerType(View.LAYER_TYPE_HARDWARE, null)

                            // Accept cookies needed for player sessions
                            val cookieManager = CookieManager.getInstance()
                            cookieManager.setAcceptCookie(true)
                            cookieManager.setAcceptThirdPartyCookies(this, true)

                            // Configure player settings
                            settings.apply {
                                javaScriptEnabled = true
                                domStorageEnabled = true
                                databaseEnabled = true
                                mediaPlaybackRequiresUserGesture = false
                                mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
                                allowFileAccess = false
                                allowContentAccess = false
                                loadWithOverviewMode = true
                                useWideViewPort = true
                                defaultTextEncodingName = "UTF-8"
                                cacheMode = WebSettings.LOAD_DEFAULT

                                // Remove WebView identifier so players serve standard stream
                                val defaultUa = userAgentString
                                if (defaultUa.contains("; wv")) {
                                    userAgentString = defaultUa.replace("; wv", "")
                                }
                            }

                            webChromeClient = object : WebChromeClient() {
                                override fun onProgressChanged(view: WebView?, newProgress: Int) {
                                    if (newProgress >= 75) {
                                        isLoading = false
                                    }
                                }

                                override fun onShowCustomView(
                                    view: View?,
                                    callback: CustomViewCallback?
                                ) {
                                    customView = view
                                    customViewCallback = callback
                                }

                                override fun onHideCustomView() {
                                    customViewCallback?.onCustomViewHidden()
                                    customView = null
                                    customViewCallback = null
                                }
                            }

                            webViewClient = object : WebViewClient() {
                                override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                                    super.onPageStarted(view, url, favicon)
                                }

                                override fun onPageFinished(view: WebView?, url: String?) {
                                    super.onPageFinished(view, url)
                                    isLoading = false
                                }

                                override fun shouldOverrideUrlLoading(
                                    view: WebView?,
                                    request: WebResourceRequest?
                                ): Boolean {
                                    val uri = request?.url ?: return false
                                    val host = uri.host.orEmpty().lowercase()
                                    val scheme = uri.scheme.orEmpty().lowercase()

                                    // Let all sub-resources (video streams, thumbnails, scripts) load
                                    if (request.isForMainFrame == false) {
                                        return false
                                    }

                                    // Allow player embed domains to load
                                    val isAllowed = host.contains("youtube.com") ||
                                            host.contains("youtube-nocookie.com") ||
                                            host.contains("googlevideo.com") ||
                                            host.contains("ytimg.com") ||
                                            host.contains("vimeo.com") ||
                                            host.contains("vimeocdn.com") ||
                                            scheme == "data" ||
                                            scheme == "about"

                                    if (isAllowed) {
                                        return false
                                    }

                                    // Block all outside navigations / ads to keep child safe
                                    return true
                                }
                            }

                            webViewInstance = this

                            val (html, baseUrl) = generatePlayerPayload(video)
                            loadDataWithBaseURL(baseUrl, html, "text/html", "UTF-8", null)
                        }
                    },
                    update = { view ->
                        webViewInstance = view
                    },
                    modifier = Modifier
                        .fillMaxSize()
                        .testTag("secure_webview_player")
                )

                if (isLoading) {
                    CircularProgressIndicator(
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.align(Alignment.Center)
                    )
                }
            }
        }
    }
}

/**
 * Extracts a YouTube video ID from various YouTube URL formats.
 */
private fun extractYouTubeId(url: String): String? {
    return try {
        if (url.contains("youtube.com/embed/")) {
            url.substringAfter("youtube.com/embed/").substringBefore("?").substringBefore("/")
        } else if (url.contains("youtube-nocookie.com/embed/")) {
            url.substringAfter("youtube-nocookie.com/embed/").substringBefore("?").substringBefore("/")
        } else if (url.contains("watch?v=")) {
            url.substringAfter("watch?v=").substringBefore("&").substringBefore("?")
        } else if (url.contains("youtu.be/")) {
            url.substringAfter("youtu.be/").substringBefore("?").substringBefore("/")
        } else if (url.contains("/shorts/")) {
            url.substringAfter("/shorts/").substringBefore("?").substringBefore("/")
        } else {
            null
        }
    } catch (e: Exception) {
        null
    }
}

/**
 * Extracts a Vimeo video ID from Vimeo URL formats.
 */
private fun extractVimeoId(url: String): String? {
    return try {
        if (url.contains("player.vimeo.com/video/")) {
            url.substringAfter("player.vimeo.com/video/").substringBefore("?").substringBefore("/")
        } else if (url.contains("vimeo.com/")) {
            url.substringAfter("vimeo.com/").substringBefore("?").substringBefore("/")
        } else {
            null
        }
    } catch (e: Exception) {
        null
    }
}

/**
 * Generates an optimized HTML wrapper and corresponding baseUrl for embedding
 * video streams without triggering referer or configuration errors (e.g., YouTube Error 153).
 */
private fun generatePlayerPayload(video: VideoItem): Pair<String, String> {
    val url = video.url.trim()
    val isYouTube = video.platform.equals("YouTube", ignoreCase = true) ||
            url.contains("youtube") || url.contains("youtu.be")
    val isVimeo = video.platform.equals("Vimeo", ignoreCase = true) ||
            url.contains("vimeo")

    if (isYouTube) {
        val ytid = extractYouTubeId(url) ?: url.substringAfterLast("/").substringAfterLast("=")
        val html = """
            <!DOCTYPE html>
            <html>
            <head>
                <meta charset="utf-8">
                <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
                <meta name="referrer" content="strict-origin-when-cross-origin">
                <style>
                    * { margin: 0; padding: 0; box-sizing: border-box; }
                    html, body {
                        width: 100%;
                        height: 100%;
                        background-color: #000000;
                        overflow: hidden;
                        display: flex;
                        align-items: center;
                        justify-content: center;
                    }
                    .player-container {
                        position: relative;
                        width: 100%;
                        height: 100%;
                    }
                    iframe {
                        position: absolute;
                        top: 0;
                        left: 0;
                        width: 100%;
                        height: 100%;
                        border: 0;
                    }
                </style>
            </head>
            <body>
                <div class="player-container">
                    <iframe 
                        src="https://www.youtube-nocookie.com/embed/$ytid?autoplay=1&playsinline=1&rel=0&modestbranding=1&enablejsapi=1" 
                        title="YouTube Video Player"
                        frameborder="0" 
                        allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" 
                        referrerpolicy="strict-origin-when-cross-origin"
                        allowfullscreen>
                    </iframe>
                </div>
            </body>
            </html>
        """.trimIndent()
        return html to "https://www.youtube-nocookie.com"
    } else if (isVimeo) {
        val vimeoId = extractVimeoId(url) ?: url.substringAfterLast("/")
        val html = """
            <!DOCTYPE html>
            <html>
            <head>
                <meta charset="utf-8">
                <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
                <style>
                    * { margin: 0; padding: 0; box-sizing: border-box; }
                    html, body {
                        width: 100%;
                        height: 100%;
                        background-color: #000000;
                        overflow: hidden;
                        display: flex;
                        align-items: center;
                        justify-content: center;
                    }
                    .player-container {
                        position: relative;
                        width: 100%;
                        height: 100%;
                    }
                    iframe {
                        position: absolute;
                        top: 0;
                        left: 0;
                        width: 100%;
                        height: 100%;
                        border: 0;
                    }
                </style>
            </head>
            <body>
                <div class="player-container">
                    <iframe 
                        src="https://player.vimeo.com/video/$vimeoId?autoplay=1&playsinline=1&title=0&byline=0&portrait=0" 
                        title="Vimeo Video Player"
                        frameborder="0" 
                        allow="autoplay; fullscreen; picture-in-picture" 
                        allowfullscreen>
                    </iframe>
                </div>
            </body>
            </html>
        """.trimIndent()
        return html to "https://player.vimeo.com"
    } else {
        // Generic / Direct video or embed
        val isDirectFile = url.endsWith(".mp4", ignoreCase = true) || 
                           url.endsWith(".webm", ignoreCase = true) ||
                           url.endsWith(".m3u8", ignoreCase = true)

        val html = """
            <!DOCTYPE html>
            <html>
            <head>
                <meta charset="utf-8">
                <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
                <style>
                    * { margin: 0; padding: 0; box-sizing: border-box; }
                    html, body {
                        width: 100%;
                        height: 100%;
                        background-color: #000000;
                        overflow: hidden;
                        display: flex;
                        align-items: center;
                        justify-content: center;
                    }
                    video, iframe {
                        width: 100%;
                        height: 100%;
                        border: 0;
                    }
                </style>
            </head>
            <body>
                ${if (isDirectFile) {
                    """<video controls autoplay playsinline src="$url"></video>"""
                } else {
                    """<iframe src="$url" allow="autoplay; fullscreen" allowfullscreen></iframe>"""
                }}
            </body>
            </html>
        """.trimIndent()
        val base = if (url.startsWith("http")) url else "https://localhost"
        return html to base
    }
}

